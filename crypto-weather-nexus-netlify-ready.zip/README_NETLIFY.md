# Deploying CryptoWeather Nexus on Netlify

1. Extract the ZIP
2. Install dependencies: `npm install`
3. Copy `.env.local.example` to `.env.local` and add API keys
4. Build: `npm run build`
5. Deploy using Netlify UI or CLI: `netlify deploy --prod`